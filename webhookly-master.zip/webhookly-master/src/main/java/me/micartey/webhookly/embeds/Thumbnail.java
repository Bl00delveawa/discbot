package me.micartey.webhookly.embeds;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class Thumbnail {

    private final String url;

}