package me.micartey.webhookly.embeds;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class Footer {

    private final String text;
    private final String iconUrl;

}
